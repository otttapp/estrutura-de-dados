package UNI1.aula1.exercicio1;

public class ListaEstatica {

    private int[] info;
    private int tamanho;

    public ListaEstatica() {
        info = new int[10];
        tamanho = 0;
    }

    private void redimensionar() {
        int[] novo;
        int novoTamanho = info.length + 10;
        novo = new int[novoTamanho];
        for (int i = 0; i < tamanho; i++) {
            novo[i] = info[i];
        }
        info = novo;
    }

    public void inserir(int valor) {
        if (tamanho == info.length) {
            redimensionar();
        }
        info[tamanho] = valor;
        tamanho++;
    }

    public void exibir() {
        for (int i = 0; i < tamanho; i++) {
            System.out.println(info[i]);
        }
    }

    public int buscar(int valor) {
        for (int i = 0; i < tamanho; i++) {
            if (info[i] == valor) {
                return i;
            }
        }
        return -1;
    }

    public void retirar(int valor) {
        int pos = buscar(valor);
        if (pos == -1) {
            return;
        }
        for (int i = pos; i < tamanho - 1; i++) {
            info[i] = info[i + 1];
        }
        tamanho--;
    }

    public boolean estaVazia() {
        return tamanho == 0;
    }

    public void liberar() {
        info = new int[10];
        tamanho = 0;
    }

    public int getTamanho() {
        return tamanho;
    }

    public String toString() {
        if (tamanho == 0) {
            return "";
        }
        String retorno = "" + info[0];
        for (int i = 1; i < tamanho; i++) {
            retorno += "," + info[i];
        }
        return retorno;
    }

    public int obterElemento(int posicao) {
        if (posicao >= tamanho || posicao < 0) {
            throw new IndexOutOfBoundsException();
        }
        return info[posicao];
    }
}
